INSERT INTO chromosome (num_k, taille, is_somatique) VALUES (1, 30973317, TRUE);
INSERT INTO chromosome (num_k, taille, is_somatique) VALUES (2, )